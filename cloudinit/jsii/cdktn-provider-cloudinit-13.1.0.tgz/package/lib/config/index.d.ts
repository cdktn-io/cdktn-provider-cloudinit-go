/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specify whether or not to base64 encode the `rendered` output. Defaults to `true`, and cannot be disabled if gzip is `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#base64_encode Config#base64_encode}
    */
    readonly base64Encode?: boolean | cdktn.IResolvable;
    /**
    * Specify the Writer's default boundary separator. Defaults to `MIMEBOUNDARY`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#boundary Config#boundary}
    */
    readonly boundary?: string;
    /**
    * Specify whether or not to gzip the `rendered` output. Defaults to `true`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#gzip Config#gzip}
    */
    readonly gzip?: boolean | cdktn.IResolvable;
    /**
    * part block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#part Config#part}
    */
    readonly part?: ConfigPart[] | cdktn.IResolvable;
}
export interface ConfigPart {
    /**
    * Body content for the part.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#content Config#content}
    */
    readonly content: string;
    /**
    * A MIME-style content type to report in the header for the part. Defaults to `text/plain`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#content_type Config#content_type}
    */
    readonly contentType?: string;
    /**
    * A filename to report in the header for the part.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#filename Config#filename}
    */
    readonly filename?: string;
    /**
    * A value for the `X-Merge-Type` header of the part, to control [cloud-init merging behavior](https://cloudinit.readthedocs.io/en/latest/reference/merging.html).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#merge_type Config#merge_type}
    */
    readonly mergeType?: string;
}
export declare function configPartToTerraform(struct?: ConfigPart | cdktn.IResolvable): any;
export declare function configPartToHclTerraform(struct?: ConfigPart | cdktn.IResolvable): any;
export declare class ConfigPartOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ConfigPart | cdktn.IResolvable | undefined;
    set internalValue(value: ConfigPart | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _contentType?;
    get contentType(): string;
    set contentType(value: string);
    resetContentType(): void;
    get contentTypeInput(): string | undefined;
    private _filename?;
    get filename(): string;
    set filename(value: string);
    resetFilename(): void;
    get filenameInput(): string | undefined;
    private _mergeType?;
    get mergeType(): string;
    set mergeType(value: string);
    resetMergeType(): void;
    get mergeTypeInput(): string | undefined;
}
export declare class ConfigPartList extends cdktn.ComplexList {
    internalValue?: ConfigPart[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ConfigPartOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config cloudinit_config}
*/
export declare class Config extends cdktn.TerraformResource {
    static readonly tfResourceType = "cloudinit_config";
    /**
    * Generates CDKTN code for importing a Config resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Config to import
    * @param importFromId The id of the existing Config that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Config to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/cloudinit/2.4.0/docs/resources/config cloudinit_config} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: ConfigConfig);
    private _base64Encode?;
    get base64Encode(): boolean | cdktn.IResolvable;
    set base64Encode(value: boolean | cdktn.IResolvable);
    resetBase64Encode(): void;
    get base64EncodeInput(): boolean | cdktn.IResolvable | undefined;
    private _boundary?;
    get boundary(): string;
    set boundary(value: string);
    resetBoundary(): void;
    get boundaryInput(): string | undefined;
    private _gzip?;
    get gzip(): boolean | cdktn.IResolvable;
    set gzip(value: boolean | cdktn.IResolvable);
    resetGzip(): void;
    get gzipInput(): boolean | cdktn.IResolvable | undefined;
    get id(): string;
    get rendered(): string;
    private _part;
    get part(): ConfigPartList;
    putPart(value: ConfigPart[] | cdktn.IResolvable): void;
    resetPart(): void;
    get partInput(): cdktn.IResolvable | ConfigPart[] | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
